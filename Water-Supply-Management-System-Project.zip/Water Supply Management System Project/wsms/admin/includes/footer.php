<div class="footer">
          <p style="color: red">&copy; 2019 WSMS . All Rights Reserved </p>
        </div>